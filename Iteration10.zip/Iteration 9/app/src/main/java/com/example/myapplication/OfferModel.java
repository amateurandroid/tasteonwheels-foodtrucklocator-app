package com.example.myapplication;


public class OfferModel {
    private String title;
    private String description;
    private String terms;

    public OfferModel(String title, String description, String terms) {
        this.title = title;
        this.description = description;
        this.terms = terms;
    }

    // Getters
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getTerms() { return terms; }
}

